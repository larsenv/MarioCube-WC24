wc24decrypt v1.0 by yellowstar6. This is a utility to decrypt WC24 files, either from locally,(HD etc) or from the servers.
Help shown when run without params:

Usage:
wc24decrypt <content.bin> <decrypt.bin> <wc24pubk.mod> <options>
The wc24pubk.mod can also by a 16 byte key.
The mod/key filename can be excluded if the content is not encrypted.
The content.bin filename can be a http(s) URL to download and decrypt.
Options:
--cache: Cache the download, don't delete it before downloading and don't disable sending the If-Modified header. Default is no cache.

Source is available on SVN at http://wmb-asm.googlecode.com/svn/trunk/wc24decrypt/

Credits:
Mike Scott for his rijndeal.c

