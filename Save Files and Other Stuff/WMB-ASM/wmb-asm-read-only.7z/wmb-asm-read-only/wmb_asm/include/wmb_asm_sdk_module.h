#ifndef _H_WMB_ASM_SDK_MODULE
#define _H_WMB_ASM_SDK_MODULE

#define ASM_SDK_MODULE

#include "wmb_asm_sdk.h"

#endif
