#ifndef _H_WMB_ASM_SDK_CLIENT
#define _H_WMB_ASM_SDK_CLIENT

#define ASM_SDK_CLIENT

//#define DLL_LOAD

#include "wmb_asm_sdk.h"

#endif
