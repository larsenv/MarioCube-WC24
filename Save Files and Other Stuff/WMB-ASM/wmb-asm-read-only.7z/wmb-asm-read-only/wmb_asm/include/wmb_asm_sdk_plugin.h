#ifndef _H_WMB_ASM_SDK_PLUGIN
#define _H_WMB_ASM_SDK_PLUGIN

#define ASM_SDK_PLUGIN

#include "wmb_asm_sdk.h"

#endif
