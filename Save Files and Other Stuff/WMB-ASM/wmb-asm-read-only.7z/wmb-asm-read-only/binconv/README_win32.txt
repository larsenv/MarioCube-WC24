Help shown when run without params:

Binconv v1.0 by yellowstar6 08/24/08
Convert Nintendo Channel DS Demo .bin files to an .nds.
Usage:
binconv <list of input demo.bin>
The output .nds will have the same filename as the input,
except the extension will be .nds.

Source is available on SVN at http://wmb-asm.googlecode.com/svn/trunk/binconv/
