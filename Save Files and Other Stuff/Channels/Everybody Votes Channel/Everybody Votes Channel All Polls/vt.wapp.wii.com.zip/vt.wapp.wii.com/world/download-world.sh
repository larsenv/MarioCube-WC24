#!/bin/bash

for D in *; do
    if [ -d "${D}" ]; then
        echo "Downloade Daten von '${D}'"
	cd "${D}"
	wget -nv http://vt.wapp.wii.com/world/"${D}"/{01..12}{01..31}_r.bin
	cd ..
	echo
	echo -------
    fi
done

exit 0